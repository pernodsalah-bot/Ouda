OUDA Android project

This is the Android Studio source project for the OUDA cruise-careers app.
It is NOT a compiled APK.

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder (OUDA-Android-Project) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

The app loads the included HTML from app/src/main/assets/index.html.
